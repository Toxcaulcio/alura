# Barbearia-Alura
Site comercial desenvolvido para uma Barbearia, empregando  HTML e CSS.




https://user-images.githubusercontent.com/104083691/173892045-30f0adfc-3900-4edc-a84f-74709dd7487f.mp4



https://user-images.githubusercontent.com/104083691/173892082-c55f8268-7ce0-4c0c-b365-c4facf3bfdb4.mp4

## 💻 Projeto

Site comercial desenvolvido para uma barbearia.

## :hammer_and_wrench: Features:

-   [ ] Criação de uma página web;
-   [ ] Posicionamento, listas e navegação;
-   [ ] Trabalhando com formulários e tabelas;
-   [ ] Utilização de Reset Css;
-   [ ] Empregando Z-Index;


## ✨ Linguagens utilizadas:

-   [ ] HTML.
-   [ ] CSS.

## 🔖 Layout:

Você pode visualizar o layout do projeto através [desse link](https://thaizacapelao.github.io/Barbearia-Alura/).
